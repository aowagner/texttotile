// Learn more about Tauri commands at https://tauri.app/develop/calling-rust/
/*#[tauri::command]
fn greet(name: &str) -> String {
    format!("Hello, {}! You've been greeted from Rust!", name)
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        	.plugin(tauri_plugin_dialog::init())
        	.plugin(tauri_plugin_fs::init())
        .invoke_handler(tauri::generate_handler![greet])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
*/



// jk added:

use std::{
    collections::HashMap,
    path::PathBuf,
    sync::Mutex,
    time::{Duration, Instant},
};

use tauri::{AppHandle, State};
use tauri::Emitter;			// jk added

use notify::{Event, RecommendedWatcher, RecursiveMode, Watcher};
use notify::Result as NotifyResult;




// ---- existing greet command ----
#[tauri::command]
fn greet(name: &str) -> String {
    format!("Hello, {}! You've been greeted from Rust!", name)
}

// ---- watcher state ----
struct Watchers(Mutex<HashMap<String, RecommendedWatcher>>);


// Start watching one file path; emits "file-changed" events to JS.
#[tauri::command]
fn start_watch_file(app: AppHandle, state: State<Watchers>, path: String) -> Result<(), String> {
    let pathbuf = PathBuf::from(&path);

    let mut last_emit = Instant::now()
        .checked_sub(Duration::from_millis(1000))
        .unwrap_or_else(Instant::now);

    let app_clone = app.clone();
    let path_clone = path.clone();

    let mut watcher = notify::recommended_watcher(move |res: NotifyResult<Event>| {
        if res.is_err() {
            return;
        }

        // Debounce bursts/atomic saves
        let now = Instant::now();
        if now.duration_since(last_emit) < Duration::from_millis(150) {
            return;
        }
        last_emit = now;

        // Emit event to the frontend
        let _ = app_clone.emit("file-changed", path_clone.clone());
    })
    .map_err(|e| e.to_string())?;

    watcher
        .watch(&pathbuf, RecursiveMode::NonRecursive)
        .map_err(|e| e.to_string())?;

    // Keep watcher alive by storing it
    state
        .0
        .lock()
        .map_err(|_| "Watcher lock poisoned".to_string())?
        .insert(path.clone(), watcher);

    Ok(())
}



#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .manage(Watchers(Mutex::new(HashMap::new())))
        .invoke_handler(tauri::generate_handler![greet, start_watch_file])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}

