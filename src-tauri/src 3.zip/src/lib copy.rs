use std::{
    path::PathBuf,
    sync::Mutex,
    time::{Duration, Instant},
};

use tauri::Emitter;
use tauri::{AppHandle, State};

use notify::Result as NotifyResult;
use notify::{Event, RecommendedWatcher, RecursiveMode, Watcher};

// ---- existing greet command ----
#[tauri::command]
fn greet(name: &str) -> String {
    format!("Hello, {}! You've been greeted from Rust!", name)
}

// ---- single watcher slot state ----
// We keep exactly ONE active watcher at a time.
// Opening a new file replaces (drops) the previous watcher automatically.
struct WatcherState(Mutex<Option<RecommendedWatcher>>);

// Start watching one file path; emits "file-changed" events to JS.
#[tauri::command]
fn start_watch_file(
    app: AppHandle,
    state: State<WatcherState>,
    path: String,
) -> Result<(), String> {
    let pathbuf = PathBuf::from(&path);

    // Debounce bursts/atomic saves (e.g. editors writing temp files).
    let mut last_emit = Instant::now()
        .checked_sub(Duration::from_millis(1000))
        .unwrap_or_else(Instant::now);

    let app_clone = app.clone();
    let path_clone = path.clone();

    let mut watcher = notify::recommended_watcher(move |res: NotifyResult<Event>| {
        if res.is_err() {
            return;
        }

        let now = Instant::now();
        if now.duration_since(last_emit) < Duration::from_millis(150) {
            return;
        }
        last_emit = now;

        // Emit event to the frontend with the path as payload
        let _ = app_clone.emit("file-changed", path_clone.clone());
    })
    .map_err(|e| e.to_string())?;

    watcher
        .watch(&pathbuf, RecursiveMode::NonRecursive)
        .map_err(|e| e.to_string())?;

    // Replace any existing watcher (dropping it stops watching the old file)
    let mut slot = state
        .0
        .lock()
        .map_err(|_| "Watcher lock poisoned".to_string())?;
    *slot = Some(watcher);

    Ok(())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_persisted_scope::init())
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .manage(WatcherState(Mutex::new(None)))
        .invoke_handler(tauri::generate_handler![greet, start_watch_file])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
