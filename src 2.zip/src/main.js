// Learn more about Tauri commands at https://tauri.app/develop/calling-rust/
const { invoke } = window.__TAURI__.core;

let currentPath = null;

window.addEventListener("DOMContentLoaded", async () => {
	document.querySelector("#do-greet").addEventListener("click", greet);	//or: document.querySelector("#do-greet").addEventListener("click", (e) => {e.preventDefault(); greet();});
	document.querySelector("#open-file").addEventListener("click", openFile);
	
	// Listen for watcher events from Rust
	window.__TAURI__.event.listen("file-changed", async (event) => {
		const changedPath = event.payload;
		if (!currentPath || changedPath !== currentPath) return;
		
		// Small delay helps with atomic saves (file replaced then written)
		setTimeout(() => readAndRender(changedPath), 50);
	});
});

async function greet(e) {
	e.preventDefault();
	document.querySelector("#greet-msg").textContent = await invoke("greet", { name: document.querySelector("#greet-input").value });
}

async function openFile() {
	const { open } = window.__TAURI__.dialog;
	
	const path = await open({
		multiple: false,
		directory: false,
		filters: [{ name: "Text", extensions: ["md", "txt", "json"] }],
	});
	
	if (!path) return;
	
	currentPath = path;
	await readAndRender(path);
	
	// Start watcher (Rust)
	await window.__TAURI__.core.invoke("start_watch_file", { path });
}

async function readAndRender(path) {
	const { readTextFile } = window.__TAURI__.fs;
	const text = await readTextFile(path);
	
	document.querySelector("#file-path").textContent = path;
	document.querySelector("#file-contents").textContent = text;
}
