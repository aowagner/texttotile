const { invoke } = window.__TAURI__.core;

let greetInputEl;
let greetMsgEl;

async function greet() {
  // Learn more about Tauri commands at https://tauri.app/develop/calling-rust/
  greetMsgEl.textContent = await invoke("greet", { name: greetInputEl.value + '!!!' });
}

/*
window.addEventListener("DOMContentLoaded", () => {
  greetInputEl = document.querySelector("#greet-input");
  greetMsgEl = document.querySelector("#greet-msg");
  document.querySelector("#greet-form").addEventListener("submit", (e) => {
    console.log('jk TEST3A');
	e.preventDefault();
    //+greet();
	openFile();
  });
}); */


window.addEventListener("DOMContentLoaded", async () => {
  document.querySelector("#open-file").addEventListener("click", openFile);

  // Listen for watcher events from Rust
  window.__TAURI__.event.listen("file-changed", async (event) => {
    const changedPath = event.payload;
    if (!currentPath || changedPath !== currentPath) return;

    // Small delay helps with atomic saves (file replaced then written)
    setTimeout(() => readAndRender(changedPath), 50);
  });

});


// jk added:

let openBtn, pathEl, outputEl;

async function openFileOld() {
  const { open } = window.__TAURI__.dialog;
  const { readTextFile } = window.__TAURI__.fs;

  const path = await open({
    multiple: false,
    directory: false,
    filters: [{ name: "Text", extensions: ["md", "txt", "json"] }]
  });

  if (!path) return;

  greetMsgEl.textContent = path;
  const text = await readTextFile(path);
  console.log('TEXT FROM FILE:\n' + text);

  //pathEl.textContent = path;
  //outputEl.textContent = text;


}

/*
window.addEventListener("DOMContentLoaded", () => {
  openBtn = document.querySelector("#open-file");
  pathEl = document.querySelector("#file-path");
  outputEl = document.querySelector("#file-contents");

  openBtn.addEventListener("click", openFile);
});
*/


// jk added: new for watch:


let currentPath = null;

async function readAndRender(path) {
  const { readTextFile } = window.__TAURI__.fs;
  const text = await readTextFile(path);

  document.querySelector("#file-path").textContent = path;
  document.querySelector("#file-contents").textContent = text;
}



async function openFile() {
  const { open } = window.__TAURI__.dialog;

  const path = await open({
    multiple: false,
    directory: false,
    filters: [{ name: "Text", extensions: ["md", "txt", "json"] }],
  });

  if (!path) return;

  currentPath = path;
  await readAndRender(path);

  // Start watcher (Rust)
  await window.__TAURI__.core.invoke("start_watch_file", { path });
}




